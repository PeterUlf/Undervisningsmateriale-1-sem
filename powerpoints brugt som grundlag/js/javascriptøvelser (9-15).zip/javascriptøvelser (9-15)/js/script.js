// JavaScript øvelser (9-15)
//
// I det følgende finder du en række øvelser.
// De er lettest i starten og bliver stadigt mere komplicerede.
// Der vil være en del gentagelser.
// Det handler nemlig både om at regne ud hvordan man gør men også om at få lidt rutine.
//
// Jeg har lavet HTML dokumentet og CSS dokumentet, så du skal kun arbejde i denne fil.
// Men du bliver nødt til at have HTML filen åben (f.eks. i split view), så du ved hvilke elementer du skal vælge.
//
// Løsningsforslag til hver af øvelserne findes i sidste del af filen her.
// Brug løsningsforslagene til at guide dig på vej, hvis du er kørt fast.
// Du kan også kopiere dem og så forsøge at rette lidt i dem, for at se hvad der sker.
//
// Når du har løst en opgave, så udkommenter den og gå videre til den næste.
//
// NB: Husk at have inspektoren åben i din browser og åben konsollen (brug [ESC] til at åbne/lukke konsollen).

//
/* ØVELSE 9: Lav en funktion (1) */
// Du skal lave en funktion, der hedder "myFunction", der skriver sit eget navn i konsollen.
// Kald (invoke) funktionen lige efter (eller kald den direkte i konsollen i din browser)
// HINT: Du kan invoke en funktion ved at skrive dens navn efterfulgt af parenteser.
// Skriv din kode i næste linje

//
/* ØVELSE 10: Lav en funktion (2) */
// Lav en funktion, der tilføjer en baggrundsfarve til sektionen med id'en "topic1"

//
/* ØVELSE 11: Lav en funktion (3) */
// Lav en funktion, der giver sektionen (id="topic1") hvid baggrund igen.

// *************** INTERMISSION *************** //
// Når du har lavet øvelse 10 og 11, så prøv lige at bruge
// konsollen til at kalde de to funktioner et par gange.
// Husk at du skal inkludere parenteser, når du kalder en funktion.
// HINT: Du kan bruge pil op og pil ned til at finde tidligere kommandoer i konsollen.
// *************** INTERMISSION *************** //

//
/* ØVELSE 12: Lav en eventListener og en funktion */
// Sæt en eventListener (click) på det første billede, lad eventet kalde en funktion, der giver billedet en border.

/* ØVELSE 13: Lav en eventListener og en funktion (2) */
// Sæt en eventListener (click) på det første billede, lad eventet kalde en funktion, der der skifter billedets source. Dvs. at billedet skiftes ud. Du kan skifte til "dock.webp", som allerede ligger i img-mappen.
// HINT: Du kan bruge "src" attributten til at ændre billedets source. Ligesom du brugte "style" attributten til at ændre CSS.

//
/* ØVELSE 14: Brug en mouseover eventListener */
// Når brugeren fører musen henover en <div>'en "area2-1" skal den få gul baggrund
// Du skal bruge eventlisteneren "mouseover"

//
/* ØVELSE 15: Brug en mouseover og en mouseout eventListener */
// Når brugeren fører musen henover en <div>'en "area2-1" skal den få gul baggrund
// Men denne gang, skal den gule baggrund forsvinde, når musen fjernes igen.
// Du skal bruge de to eventlistener "mouseover" og "mouseout"

// Bonus: Flere areas kan reagere på den samme mouseover
// Prøv at udvide øvelse 15, så det er alle 'area'-diverne i sektion 2, der skifter farve,
// når man kører musen henover area2-1
// ... det bliver en linje for hver area i begge funktioner
// Bonus 2: Flere sektioner aktiverer funtionen
// Ligesom Bonus, men nu skal 'area'-diverne i sektion 2 lyse op hvis man hover
// en hvilken som helst tekst-div (dvs. area2-1 og area2-3)
// ... der skal bruges en eventlistener mere både til mouseover og mouseout

/* ****************************************************************************************** */
/* Løsningsforslag */
/* ****************************************************************************************** */
//
// Løsning til "ØVELSE 9: Lav en funktion (1)""
// function myFunction() {
//   console.log("myFunction");
// }
// myFunction();
// -----------------------------------------------------------------------------------
// Løsning til "ØVELSE 10: Lav en funktion (2)""
// function changeBackground() {
//   console.log("changeBackground");
//   document.querySelector("#topic1").style.backgroundColor = "hsl(120, 100%, 50%)";
// }
// changeBackground();
// -----------------------------------------------------------------------------------
// Løsning til "ØVELSE 11: Lav en funktion (3)"
// function normalizeBackground() {
//   console.log("normalizeBackground");
//   document.querySelector("#topic1").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
// }
// normalizeBackground();
// // -----------------------------------------------------------------------------------
// Løsning til "ØVELSE 12: Lav en eventListener og en funktion"
// document.querySelector("#area1-3 img").addEventListener("click", addBorder);
// function addBorder() {
//   document.querySelector("#area1-3 img").style.border = "5px solid black";
// }

// Løsning til "ØVELSE 13: Brug en eventListener"
// document.querySelector("#area1-3 img").addEventListener("click", addBorder);
// function addBorder() {
//   document.querySelector("#area1-3 img").src = "img/dock.webp";
// }
//
// Løsning til "ØVELSE 14: Brug en mouseover eventListener"
// document.querySelector("#area2-1").addEventListener("mouseover", highlight1);
// function highlight1() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(60, 100%, 50%)";
// }
//
// Løsning til "ØVELSE 15: Brug en mouseover og en mouseout eventListener"
// document.querySelector("#area2-1").addEventListener("mouseover", highlight1);
// document.querySelector("#area2-1").addEventListener("mouseout", normalize);
// function highlight1() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(60, 100%, 50%)";
// }
// function normalize() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
// }

// Bonus
// document.querySelector("#area2-1").addEventListener("mouseover", highlight1);
// document.querySelector("#area2-1").addEventListener("mouseout", normalize);
// function highlight1() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(60, 100%, 50%)";
//   document.querySelector("#area2-2").style.backgroundColor = "hsl(60, 100%, 50%)";
//   document.querySelector("#area2-3").style.backgroundColor = "hsl(60, 100%, 50%)";
// }
// function normalize() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
//   document.querySelector("#area2-2").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
//   document.querySelector("#area2-3").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
// }

// Bonus 2
// document.querySelector("#area2-1").addEventListener("mouseover", highlight1);
// document.querySelector("#area2-3").addEventListener("mouseover", highlight1);
// document.querySelector("#area2-1").addEventListener("mouseout", normalize);
// document.querySelector("#area2-3").addEventListener("mouseout", normalize);
// function highlight1() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(60, 100%, 50%)";
//   document.querySelector("#area2-2").style.backgroundColor = "hsl(60, 100%, 50%)";
//   document.querySelector("#area2-3").style.backgroundColor = "hsl(60, 100%, 50%)";
// }
// function normalize() {
//   document.querySelector("#area2-1").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
//   document.querySelector("#area2-2").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
//   document.querySelector("#area2-3").style.backgroundColor = "hsl(0, 0.00%, 100.00%)";
// }
