// JavaScript øvelser (1-8)
//
// I det følgende finder du en række øvelser.
// De er lettest i starten og bliver stadigt mere komplicerede.
// Der vil være en del gentagelser.
// Det handler nemlig både om at regne ud hvordan man gør men også om at få lidt rutine.
//
// Jeg har lavet HTML dokumentet og CSS dokumentet, så du skal kun arbejde i denne fil.
// Men du bliver nødt til at have HTML filen åben (f.eks. i split view), så du ved hvilke elementer du skal vælge.
//
// Løsningsforslag til hver af øvelserne findes i sidste del af filen her.
// Brug løsningsforslagene til at guide dig på vej, hvis du er kørt fast.
// Du kan også kopiere dem og så forsøge at rette lidt i dem, for at se hvad der sker.
//
// Når du har løst en opgave, så udkommenter den og gå videre til den næste.
//
// NB: Husk at have web developer tools åben i din browser (option+command+i for at åbne den) og åben konsollen (brug [ESC] til at åbne/lukke konsollen).

//
/* ---> ØVELSE 1: tilføj style til et HTML element */
// Du skal vælge det element, der har id'en "area1-1" og tilføje en baggrundsfarve."
// HINT: Du skal bruge style metoden til at tilføje en baggrundsfarve til et element.
// HINT: En CSS property, der i CSS skrives med bindestreg, skrives i JavaScript med camelCase.
// Skriv din kode i næste linje:

//
/* ---> ØVELSE 2: tilføj style til et HTML element */
// Du skal vælge den tredje <div> i sektionen med id'en "topic2" og tilføje en border til elementet.

//
/* ---> ØVELSE 3: tilføj style til et HTML element */
// Du skal vælge den første <p> i første <div> i hver sektion og gøre teksten rød.
// HINT: Det kræver mere end én linje kode.

//
/* ---> ØVELSE 4: tilføj style til et HTML element */
// Du skal vælge den tredje <p> i den tredje <div> i den anden <section> og tilføje en border og en box-shadow til elementet.

//
/* ---> ØVELSE 5: lav en ny tekst til et HTML element */
// Vælg den første paragraf i tredje section og ændr teksten i paragraffen til "Jeg er en ny tekst".
// HINT: Du skal bruge textContent metoden til at ændre teksten i et element.

//
/* ---> ØVELSE 6: lav en ny HTML-markeret tekst til et HTML element */
// Vælg den første paragraf i tredje section og ændr teksten i paragraffen til "Jeg er en ny tekst". Ordene "en ny tekst" skal være markeret med <mark> tags.
// HINT: Du skal bruge innerHTML metoden til at tilføje HTML til et element.

//
//* ---> ØVELSE 7: Aflæs vidden på et element */
// Du skal aflæse vidden på det billede, der er i den tredje <div> i den første <section> og skrive vidden i konsollen.
// HINT: Du skal bruge clientWidth metoden til at aflæse vidden på et element (prøv at søg på nettet for at se hvordan man bruger den).
// HINT: Du skal bruge querySelector metoden til at vælge et element.
// HINT: Du skal bruge console.log metoden til at skrive noget i konsollen.
// NOTE: Prøv at resize dit browser-vindue og reload siden (tjek billedets bredde).

//
// /* ---> ØVELSE 8: Aflæs vidden på et element (2) */
// Du skal igen aflæse vidden på det billede, der er i den tredje <div> i den første <section.
// Men denne gang skal du også aflæse vidden på den <div>, som billedet er i.
// HINT: Du skal bruge parentNode metoden til at vælge et elements forælder element.

// BEMÆRK
// Det ser ud til at der er en forskel på vidden på billedet og vidden på den <div>, som billedet er i.
// Hvad skyldes forskellen?

/* ****************************************************************************************** */
/* Løsningsforslag */
/* ****************************************************************************************** */
//
// Løsning til "ØVELSE 1: tilføj style til et HTML element"
// document.querySelector("#area1-1").style.backgroundColor = "#ccc";
//
// Løsning til "ØVELSE 2: tilføj style til et HTML element"
// løsningsforslag 1:
// document.querySelector("#area2-3").style.border = "2px solid black";
//løsningsforslag 2:
// document.querySelector("#topic2>div:nth-child(3)").style.border = "2px solid black";
//
// Løsning til "ØVELSE 3: tilføj style til et HTML element"
// NOTE: Da querySelector kun vælger ét (det første) element der matcher css-selectoren, kan vi ikke vælge de første 2 pragraffer med: section > div:first-of-type > p:first-child
// document.querySelector("#area1-1 p:first-child").style.color = "#f00";
// document.querySelector("#area2-1 p:first-child").style.color = "#f00";
// document.querySelector("#area3-2 p:first-child").style.color = "#f00";

// Løsning til "ØVELSE 4: tilføj style til et HTML element"
// Løsningsforslag 1 (her bruges id'et på sektionen):
// document.querySelector("#area2-3>p:nth-child(3)").style.border = "1px solid black";
// document.querySelector("#area2-3>p:nth-child(3)").style.boxShadow = "5px 5px 5px #000";
// Løsningsforslag 2 (her bruges positionen af sektionen):
// document.querySelector("section:nth-of-type(2)>div:nth-child(3)>p:nth-child(3)").style.border = "1px solid black";
// document.querySelector("section:nth-of-type(2)>div:nth-child(3)>p:nth-child(3)").style.boxShadow = "5px 5px 5px #000";

// Løsning til "ØVELSE 5: lav en ny tekst til et HTML element"
// document.querySelector("#topic3 p:first-of-type").textContent = "Jeg er en ny tekst";

//
// Løsning til "ØVELSE 6: lav en ny HTML-markeret tekst til et HTML element"
// document.querySelector("#topic3 p:first-of-type").innerHTML = "Jeg er <mark>en ny tekst</mark>";

//
// Løsning til "ØVELSE 7: Aflæs vidden på et element"
// console.log(document.querySelector("#area1-3>img").clientWidth + "px");

//
// Løsning til "ØVELSE 8: Aflæs højden på et element (2)"
// console.log(document.querySelector("#area1-3>img").clientWidth + "px");
// console.log(document.querySelector("#area1-3>img").parentNode.clientWidth + "px");
